import subprocess
import os
import sys
import time
import webbrowser
import threading

def instalar_flask():
    try:
        import flask
        print("[✔] Flask já instalado.")
    except ImportError:
        print("[...] Instalando Flask...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "flask"])
        print("[✔] Flask instalado.")

def criar_pastas():
    pastas = [
        os.path.join('data', 'uploads'),
        'templates'
    ]
    for pasta in pastas:
        if not os.path.exists(pasta):
            os.makedirs(pasta)
            print(f"[✔] Pasta criada: {pasta}")
        else:
            print(f"[✔] Pasta já existe: {pasta}")

def verificar_app_py():
    if not os.path.exists('app.py'):
        print("[✖] ERRO: Arquivo app.py não encontrado na pasta atual.")
        sys.exit(1)

def abrir_navegador():
    # Espera 2 segundos para o servidor levantar
    time.sleep(2)
    webbrowser.open("http://127.0.0.1:5000/")

def executar_app():
    print("\n[🚀] Iniciando o sistema...")
    threading.Thread(target=abrir_navegador).start()
    subprocess.run([sys.executable, "app.py"])

if __name__ == "__main__":
    print("🔧 Setup do Sistema de Controle de Estudos 🔧\n")
    verificar_app_py()
    instalar_flask()
    criar_pastas()
    executar_app()
